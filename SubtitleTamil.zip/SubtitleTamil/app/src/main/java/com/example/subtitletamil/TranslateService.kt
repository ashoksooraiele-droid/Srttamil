package com.example.subtitletamil

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.Charset
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/** Activity-ku progress kaattura shared state. */
object TranslateState {
    val running = MutableStateFlow(false)
    val status = MutableStateFlow("SRT file(s) select pannunga")
    val progress = MutableStateFlow(0)
    val exit = MutableStateFlow(false)
    val live = MutableStateFlow("")
}

private class Block(val header: List<String>, val text: List<String>)

/** Oru subtitle block-la translate panna vendiya texts + adha thirumba lines-a maathura function. */
private class Prep(val texts: List<String>, val build: (List<String>) -> List<String>)

private class FileOut(val text: String, val failures: Int, val switched: Boolean)

private class RunResult(
    val ok: Int,
    val total: Int,
    val failed: List<String>,
    val notes: List<String>,
    val where: String
)

private val assLead = Regex("""^(?:\{\\[^}]*\})+""")
private val assTag = Regex("""\{\\[^}]*\}""")
private val htmlTag = Regex("<[^>]+>")
private val spaces = Regex("\\s+")
private val blockSplit = Regex("\n\\s*\n")

class TranslateService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    @Volatile
    private var lastPct = -1

    @Volatile
    private var modeLabel = "Offline"

    private val liveBuf = ArrayDeque<String>()

    private val nm: NotificationManager by lazy {
        getSystemService(NotificationManager::class.java)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            if (job?.isActive == true) job?.cancel() else stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_EXIT) {
            job?.cancel()
            TranslateState.exit.value = true
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        createChannels()
        startAsForeground("Start aagudhu...")

        if (job?.isActive == true) return START_NOT_STICKY

        val clip = intent?.clipData
        val uris = if (clip == null) emptyList()
        else (0 until clip.itemCount).mapNotNull { clip.getItemAt(it).uri }
        if (uris.isEmpty()) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        val online = intent?.getBooleanExtra(EXTRA_ONLINE, false) ?: false

        job = scope.launch {
            val wl = (getSystemService(POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SubtitleTamil:translate")
            wl.acquire(2 * 60 * 60 * 1000L)
            lastPct = 0
            modeLabel = if (online) "Online" else "Offline"
            synchronized(liveBuf) { liveBuf.clear() }
            TranslateState.live.value = ""
            TranslateState.running.value = true
            TranslateState.progress.value = 0
            try {
                val res = process(uris, online)
                TranslateState.progress.value = 100
                TranslateState.status.value = summary(res)
                showDone(res)
            } catch (e: CancellationException) {
                TranslateState.status.value = "Stop pannitten."
            } catch (e: Exception) {
                TranslateState.status.value = "Error: ${e.message}"
            } finally {
                TranslateState.running.value = false
                if (wl.isHeld) wl.release()
                ServiceCompat.stopForeground(this@TranslateService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- main flow

    private suspend fun process(uris: List<Uri>, online: Boolean): RunResult {
        val translators = HashMap<String, Translator>()
        var ok = 0
        val failed = ArrayList<String>()
        val notes = ArrayList<String>()
        var where = ""
        try {
            uris.forEachIndexed { i, uri ->
                val name = displayName(uri, i)
                try {
                    val o = translateOne(uri, name, i, uris.size, online, translators)
                    where = withContext(Dispatchers.IO) { saveOutput(name, o.text) }
                    ok++
                    if (o.failures > 0) notes.add("$name: ${o.failures} line translate aagala (original-ae irukku)")
                    if (o.switched) notes.add("$name: online fail aagi offline-la mudichen")
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    failed.add("$name: ${e.message}")
                }
            }
        } finally {
            translators.values.forEach { it.close() }
        }
        return RunResult(ok, uris.size, failed, notes, where)
    }

    private suspend fun translateOne(
        uri: Uri,
        name: String,
        idx: Int,
        count: Int,
        online: Boolean,
        translators: MutableMap<String, Translator>
    ): FileOut {
        publishStatus("File ${idx + 1}/$count: $name padikkuren...")
        val raw = withContext(Dispatchers.IO) { readText(uri) }
        val blocks = parseSrt(raw)

        // Language detect (idhu phone-laeye nadakkum): file muzhudhum irundhu 40 lines sample
        val allText = blocks.flatMap { it.text }.map { clean(it) }.filter { s -> s.any { it.isLetter() } }
        if (allText.isEmpty()) throw IOException("Subtitle text illa")
        val step = maxOf(1, allText.size / 40)
        val sample = allText.filterIndexed { i, _ -> i % step == 0 }.take(40).joinToString(" ")

        publishStatus("File ${idx + 1}/$count: language kandupidikkuren...")
        val identifier = LanguageIdentification.getClient()
        val code = try {
            identifier.identifyLanguage(sample).await()
        } finally {
            identifier.close()
        }
        if (code == "ta") throw IOException("Already Tamil")
        val srcTag = TranslateLanguage.fromLanguageTag(code)
            ?: TranslateLanguage.fromLanguageTag(code.substringBefore('-'))
        val sl = if (code == "und" || code.contains('-')) "auto" else code

        val engine = Engine(online, code, sl, srcTag, translators)
        if (!online) engine.ensureOffline()

        // Texts-a prepare pannu, apram units-a pirichchu (online: 25 blocks/request, offline: 1 block)
        val preps = blocks.map { b -> if (b.text.isEmpty()) null else prepare(b.text) }
        val maxBlocks = if (online) 25 else 1
        val units = ArrayList<List<Int>>()
        var cur = ArrayList<Int>()
        var chars = 0
        for (i in preps.indices) {
            val p = preps[i] ?: continue
            val c = p.texts.sumOf { it.length }
            if (cur.isNotEmpty() && (cur.size >= maxBlocks || chars + c > 1500)) {
                units.add(cur)
                cur = ArrayList()
                chars = 0
            }
            cur.add(i)
            chars += c
        }
        if (cur.isNotEmpty()) units.add(cur)

        val total = blocks.size
        val outLines = arrayOfNulls<List<String>>(total)
        val done = AtomicInteger(total - units.sumOf { it.size })
        val gate = Semaphore(if (online) 4 else 3)
        publish(idx, count, done.get() * 100 / total, name)

        coroutineScope {
            units.map { unit ->
                async {
                    gate.withPermit {
                        val all = unit.flatMap { preps[it]!!.texts }
                        val res = engine.translate(all)
                        var pos = 0
                        for (bi in unit) {
                            val p = preps[bi]!!
                            val n = p.texts.size
                            val lines = p.build(res.subList(pos, pos + n))
                            pos += n
                            outLines[bi] = lines
                            addLive(bi, blocks[bi].text, lines)
                        }
                    }
                    val d = done.addAndGet(unit.size)
                    publish(idx, count, d * 100 / total, name)
                }
            }.awaitAll()
        }

        val text = blocks.indices.joinToString("\n\n") { i ->
            (blocks[i].header + (outLines[i] ?: blocks[i].text)).joinToString("\n")
        } + "\n"
        return FileOut(text, engine.failures.get(), engine.switched)
    }

    // ------------------------------------------------------------ translation

    /** Online (Google) + Offline (ML Kit) rendu-kum common engine. Online fail aana offline-ku maarum. */
    private inner class Engine(
        onlineStart: Boolean,
        private val code: String,
        private val sl: String,
        private val srcTag: String?,
        private val translators: MutableMap<String, Translator>
    ) {
        @Volatile
        var online = onlineStart

        @Volatile
        var switched = false

        val failures = AtomicInteger(0)
        private var offline: Translator? = null
        private val lock = Mutex()
        private val cache = ConcurrentHashMap<String, String>()

        suspend fun ensureOffline(): Translator = lock.withLock {
            offline?.let { return@withLock it }
            val tag = srcTag ?: throw IOException("Offline-ku language support illa ($code)")
            val t = translators[tag] ?: run {
                val nt = Translation.getClient(
                    TranslatorOptions.Builder()
                        .setSourceLanguage(tag)
                        .setTargetLanguage(TranslateLanguage.TAMIL)
                        .build()
                )
                publishStatus("Offline model download aagudhu (modhal dhadava mattum)...")
                nt.downloadModelIfNeeded().await()
                translators[tag] = nt
                nt
            }
            offline = t
            t
        }

        suspend fun translate(texts: List<String>): List<String> {
            if (online) {
                try {
                    return googleTexts(texts)
                } catch (e: Exception) {
                    if (e is CancellationException) throw e
                    try {
                        ensureOffline()
                    } catch (e2: Exception) {
                        if (e2 is CancellationException) throw e2
                        throw IOException("Online fail (${e.message}), offline-um mudiyala (${e2.message})")
                    }
                    if (!switched) {
                        switched = true
                        publishStatus("Online fail aachu, offline-ku maarittu...")
                    }
                    online = false
                }
            }
            return offlineTexts(texts)
        }

        private suspend fun offlineTexts(texts: List<String>): List<String> {
            val t = ensureOffline()
            return texts.map { s ->
                cache[s] ?: try {
                    val r = t.translate(s).await()
                    cache[s] = r
                    r
                } catch (e: Exception) {
                    if (e is CancellationException) throw e
                    failures.incrementAndGet()
                    s // translate aagala na original-ae irukkum
                }
            }
        }

        private suspend fun googleTexts(texts: List<String>): List<String> {
            if (texts.size > 1) {
                try {
                    val joined = withContext(Dispatchers.IO) { googleRequest(texts.joinToString("\n")) }
                    val parts = joined.trimEnd('\n', ' ').split("\n")
                    if (parts.size == texts.size) return parts.map { it.trim() }
                } catch (e: Exception) {
                    if (e is CancellationException) throw e
                }
            }
            // Batch sari varala na ovvonna thaniya anuppu
            return texts.map { googleOne(it) }
        }

        private suspend fun googleOne(text: String): String {
            cache[text]?.let { return it }
            var last: Exception? = null
            for (attempt in 0 until 3) {
                try {
                    val r = withContext(Dispatchers.IO) { googleRequest(text) }
                    cache[text] = r
                    return r
                } catch (e: Exception) {
                    if (e is CancellationException) throw e
                    last = e
                    delay(500L * (attempt + 1))
                }
            }
            throw IOException("Google translate fail: ${last?.message}")
        }

        private fun googleRequest(q: String): String {
            val enc = URLEncoder.encode(q, "UTF-8")
            val base = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sl&tl=ta&dt=t"
            val usePost = enc.length > 1800
            val conn = URL(if (usePost) base else "$base&q=$enc").openConnection() as HttpURLConnection
            try {
                conn.connectTimeout = 15000
                conn.readTimeout = 25000
                conn.setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
                )
                if (usePost) {
                    conn.requestMethod = "POST"
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8")
                    conn.outputStream.use { it.write("q=$enc".toByteArray(Charsets.UTF_8)) }
                }
                if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
                val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val segs = JSONArray(body).getJSONArray(0)
                val sb = StringBuilder()
                for (i in 0 until segs.length()) {
                    val seg = segs.optJSONArray(i) ?: continue
                    if (!seg.isNull(0)) sb.append(seg.getString(0))
                }
                if (sb.isBlank()) throw IOException("Empty response")
                return sb.toString()
            } finally {
                conn.disconnect()
            }
        }
    }

    /** Block-oda lines-a translate panna thayaar pannu. null na translate panna onnum illa. */
    private fun prepare(lines: List<String>): Prep? {
        val dialogue = lines.size > 1 && lines.drop(1).any {
            val s = it.trimStart()
            s.startsWith("-") || s.startsWith("–")
        }
        if (lines.size == 1 || dialogue) {
            val cleaned = lines.map { clean(it).replace(spaces, " ").trim() }
            val idx = cleaned.indices.filter { i -> cleaned[i].any { it.isLetter() } }
            if (idx.isEmpty()) return null
            return Prep(idx.map { cleaned[it] }) { tr ->
                val out = lines.toMutableList()
                idx.forEachIndexed { k, li ->
                    val prefix = assLead.find(lines[li])?.value.orEmpty()
                    val r = prefix + tr[k]
                    out[li] = if (lines[li].trim().startsWith("<i>")) "<i>$r</i>" else r
                }
                out
            }
        }
        val joined = lines.joinToString(" ") { clean(it) }.replace(spaces, " ").trim()
        if (!joined.any { it.isLetter() }) return null
        val prefix = assLead.find(lines[0])?.value.orEmpty()
        return Prep(listOf(joined)) { tr ->
            val wrapped = rewrap(prefix + tr[0], lines.size)
            if (lines.all { it.trim().startsWith("<i>") }) wrapped.map { "<i>$it</i>" } else wrapped
        }
    }

    private fun clean(s: String): String = s.replace(assTag, "").replace(htmlTag, "")

    private fun rewrap(text: String, n: Int): List<String> {
        if (n <= 1) return listOf(text)
        val words = text.split(' ').filter { it.isNotEmpty() }
        if (words.size < n) return listOf(text)
        val target = text.length / n
        val result = ArrayList<String>()
        val cur = StringBuilder()
        for (w in words) {
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(w)
            if (cur.length >= target && result.size < n - 1) {
                result.add(cur.toString())
                cur.clear()
            }
        }
        if (cur.isNotEmpty()) result.add(cur.toString())
        return result
    }

    private fun addLive(blockIdx: Int, original: List<String>, translated: List<String>) {
        val src = original.joinToString(" ") { clean(it) }.replace(spaces, " ").trim()
        val dst = translated.joinToString(" ").replace(spaces, " ").trim()
        synchronized(liveBuf) {
            liveBuf.addLast("#${blockIdx + 1}  $src\n➜ $dst")
            while (liveBuf.size > 30) liveBuf.removeFirst()
            TranslateState.live.value = liveBuf.joinToString("\n\n")
        }
    }

    // --------------------------------------------------------------- file I/O

    private fun parseSrt(raw: String): List<Block> {
        val norm = raw.removePrefix("﻿").replace("\r\n", "\n").replace('\r', '\n').trim('\n')
        if (norm.isBlank()) return emptyList()
        return norm.split(blockSplit).map { chunk ->
            val lines = chunk.split("\n")
            val ti = lines.indexOfFirst { it.contains("-->") }
            if (ti < 0) Block(lines, emptyList())
            else Block(lines.subList(0, ti + 1), lines.subList(ti + 1, lines.size))
        }
    }

    private fun readText(uri: Uri): String {
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IOException("File open aagala")
        return when {
            bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte() ->
                String(bytes, Charsets.UTF_16LE)
            bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte() ->
                String(bytes, Charsets.UTF_16BE)
            else -> {
                val s = String(bytes, Charsets.UTF_8)
                if (s.contains('�')) String(bytes, Charset.forName("windows-1252")) else s
            }
        }
    }

    private fun displayName(uri: Uri, index: Int): String {
        val n = try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) {
            null
        }
        val base = n?.substringBeforeLast('.')?.takeIf { it.isNotBlank() }
        return base ?: "subtitle_${index + 1}"
    }

    private fun saveOutput(name: String, content: String): String {
        val outName = "${name}_tamil.srt"
        val bytes = content.toByteArray(Charsets.UTF_8)
        return if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, outName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/x-subrip")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SubtitleTamil")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Save panna mudiyala")
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: throw IOException("Save panna mudiyala")
            "Download/SubtitleTamil"
        } else {
            val dir = File(getExternalFilesDir(null), "SubtitleTamil")
            dir.mkdirs()
            File(dir, outName).writeBytes(bytes)
            dir.absolutePath
        }
    }

    // ---------------------------------------------------------- notifications

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH_PROGRESS, "Translate progress", NotificationManager.IMPORTANCE_LOW)
            )
            nm.deleteNotificationChannel("translate_done")
            val done = NotificationChannel(
                CH_DONE, "Translate mudinjadhu (silent)", NotificationManager.IMPORTANCE_DEFAULT
            )
            done.setSound(null, null)
            done.enableVibration(false)
            nm.createNotificationChannel(done)
        }
    }

    private fun startAsForeground(text: String) {
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        ServiceCompat.startForeground(this, NOTIF_PROGRESS, progressNotification(text, 0), type)
    }

    private fun openAppIntent(): PendingIntent =
        PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

    private fun progressNotification(text: String, percent: Int): Notification {
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, TranslateService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val exit = PendingIntent.getService(
            this, 2,
            Intent(this, TranslateService::class.java).setAction(ACTION_EXIT),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Tamil-ku translate aagudhu ($modeLabel)")
            .setContentText(text)
            .setProgress(100, percent, false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent())
            .addAction(0, "Stop", stop)
            .addAction(0, "Exit", exit)
            .build()
    }

    private fun publish(fileIdx: Int, count: Int, filePct: Int, name: String) {
        val overall = (fileIdx * 100 + filePct) / count
        val text = "[$modeLabel] File ${fileIdx + 1}/$count: $name - $filePct%"
        TranslateState.status.value = text
        if (overall != lastPct) {
            lastPct = overall
            TranslateState.progress.value = overall
            nm.notify(NOTIF_PROGRESS, progressNotification(text, overall))
        }
    }

    private fun publishStatus(text: String) {
        TranslateState.status.value = text
        nm.notify(NOTIF_PROGRESS, progressNotification(text, maxOf(0, lastPct)))
    }

    private fun summary(r: RunResult): String {
        val sb = StringBuilder()
        sb.append("${r.ok}/${r.total} file translate aayiduchu.")
        if (r.ok > 0) sb.append(" Save: ${r.where}")
        if (r.notes.isNotEmpty()) sb.append("\nNote: ").append(r.notes.joinToString("; "))
        if (r.failed.isNotEmpty()) sb.append("\nFail: ").append(r.failed.joinToString("; "))
        return sb.toString()
    }

    private fun showDone(r: RunResult) {
        val n = NotificationCompat.Builder(this, CH_DONE)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(if (r.ok == r.total) "Translate mudinjuthu" else "Translate mudinjuthu (sila fail)")
            .setContentText(summary(r).lineSequence().first())
            .setStyle(NotificationCompat.BigTextStyle().bigText(summary(r)))
            .setAutoCancel(true)
            .setSilent(true)
            .setContentIntent(openAppIntent())
            .build()
        nm.notify(NOTIF_DONE, n)
    }

    companion object {
        private const val CH_PROGRESS = "translate_progress"
        private const val CH_DONE = "translate_done_silent"
        private const val NOTIF_PROGRESS = 1
        private const val NOTIF_DONE = 2
        const val ACTION_STOP = "com.example.subtitletamil.STOP"
        const val ACTION_EXIT = "com.example.subtitletamil.EXIT"
        const val EXTRA_ONLINE = "online"
    }
}
