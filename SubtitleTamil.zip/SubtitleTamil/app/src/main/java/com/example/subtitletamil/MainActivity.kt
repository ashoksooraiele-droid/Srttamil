package com.example.subtitletamil

import android.Manifest
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var pickButton: Button
    private lateinit var stopButton: Button
    private lateinit var exitButton: Button
    private lateinit var modeOffline: RadioButton
    private lateinit var modeOnline: RadioButton
    private lateinit var liveText: TextView
    private lateinit var liveScroll: ScrollView

    private val pickFiles = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> if (uris.isNotEmpty()) startTranslate(uris) }

    // Notification permission (Android 13+). Mudivu enna aanaalum file picker open aagum.
    private val askNotification = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { pickFiles.launch(arrayOf("*/*")) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        pickButton = findViewById(R.id.btnPick)
        stopButton = findViewById(R.id.btnStop)
        exitButton = findViewById(R.id.btnExit)
        modeOffline = findViewById(R.id.modeOffline)
        modeOnline = findViewById(R.id.modeOnline)
        liveText = findViewById(R.id.liveText)
        liveScroll = findViewById(R.id.liveScroll)
        progress.max = 100
        TranslateState.exit.value = false

        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        if (prefs.getBoolean("online", false)) modeOnline.isChecked = true else modeOffline.isChecked = true
        modeOnline.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("online", checked).apply()
        }

        pickButton.setOnClickListener { pick() }
        stopButton.setOnClickListener { sendToService(TranslateService.ACTION_STOP) }
        exitButton.setOnClickListener {
            if (TranslateState.running.value) {
                sendToService(TranslateService.ACTION_EXIT)
            } else {
                finishAndRemoveTask()
            }
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { TranslateState.status.collect { status.text = it } }
                launch { TranslateState.progress.collect { progress.progress = it } }
                launch {
                    TranslateState.running.collect {
                        pickButton.isEnabled = !it
                        stopButton.isEnabled = it
                        modeOffline.isEnabled = !it
                        modeOnline.isEnabled = !it
                    }
                }
                launch {
                    TranslateState.live.collect {
                        if (it.isNotEmpty()) {
                            liveText.text = it
                            liveScroll.post { liveScroll.fullScroll(View.FOCUS_DOWN) }
                        }
                    }
                }
                launch {
                    TranslateState.exit.collect {
                        if (it) {
                            TranslateState.exit.value = false
                            finishAndRemoveTask()
                        }
                    }
                }
            }
        }
    }

    private fun sendToService(action: String) {
        startService(Intent(this, TranslateService::class.java).setAction(action))
    }

    private fun pick() {
        val needPermission = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needPermission) {
            askNotification.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            pickFiles.launch(arrayOf("*/*"))
        }
    }

    private fun startTranslate(uris: List<Uri>) {
        uris.forEach {
            try {
                contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // persist aagala na paravayilla, intent grant pothum
            }
        }
        val clip = ClipData.newRawUri("srt", uris[0])
        uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) }

        val intent = Intent(this, TranslateService::class.java).apply {
            clipData = clip
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            putExtra(TranslateService.EXTRA_ONLINE, modeOnline.isChecked)
        }
        TranslateState.running.value = true
        TranslateState.progress.value = 0
        TranslateState.status.value = "Start aagudhu..."
        TranslateState.live.value = ""
        liveText.text = "Live translate inge theriyum..."
        ContextCompat.startForegroundService(this, intent)
    }
}
